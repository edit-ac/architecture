//! Prepared semantic commands over the single authoritative replica.
pub mod format;
pub mod lists;
pub mod structure;
pub mod text;
