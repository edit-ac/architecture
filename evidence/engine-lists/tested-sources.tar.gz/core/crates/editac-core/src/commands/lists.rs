//! Read-only hierarchy validation for future list command preparation.
//!
//! This uses the frozen registry's list-parent rule. It neither adds structural
//! kinds to v3 nor implements list/quote persistence. Success is not a prepared
//! commit: a command must also validate its profile, anchors, metadata and exact
//! revision before mutation. Always validate the complete batch, not each change
//! separately: individually legal changes can jointly create a cycle.
use super::text::MAX_TEXT_DEPTH;
use crate::projection::Snapshot;
use std::collections::{BTreeMap, BTreeSet};

pub const MAX_HIERARCHY_NODES: usize = 8192;
const ROOT: &str = "@root";

/// A proposed parent relation; this does not write a placement or move text.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParentChange {
    pub node: String,
    pub parent: String,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum HierarchyError {
    ResourceLimit,
    InvalidSnapshot,
    DuplicateTarget(String),
    MissingNode(String),
    DeletedNode(String),
    UnsupportedTarget(String),
    IllegalParent(String),
    Cycle(String),
    DepthLimit(String),
}

/// Validate parent changes over a derived snapshot without altering it or Yrs.
///
/// A known parent must be a visible `list`; `@root` is the only sentinel.
/// Unknown content is retained but cannot be a semantic command target. Check
/// every descendant as well as changed nodes so moving a shallow subtree cannot
/// push its deepest children beyond the existing editing depth limit.
/// Complexity is bounded by node count and MAX_TEXT_DEPTH, without recursion.
pub fn validate_hierarchy(
    snapshot: &Snapshot,
    changes: &[ParentChange],
) -> Result<(), HierarchyError> {
    if snapshot
        .visible
        .len()
        .saturating_add(snapshot.recovery.len())
        > MAX_HIERARCHY_NODES
        || changes.len() > MAX_HIERARCHY_NODES
    {
        return Err(HierarchyError::ResourceLimit);
    }
    let mut nodes = BTreeMap::new();
    for node in &snapshot.visible {
        if node.id == ROOT || nodes.insert(node.id.as_str(), node.as_ref()).is_some() {
            return Err(HierarchyError::InvalidSnapshot);
        }
    }
    let mut deleted = BTreeSet::new();
    for node in &snapshot.recovery {
        if node.id == ROOT
            || nodes.contains_key(node.id.as_str())
            || !deleted.insert(node.id.as_str())
        {
            return Err(HierarchyError::InvalidSnapshot);
        }
    }
    let require_visible = |id: &str| {
        if deleted.contains(id) {
            Err(HierarchyError::DeletedNode(id.to_owned()))
        } else if !nodes.contains_key(id) {
            Err(HierarchyError::MissingNode(id.to_owned()))
        } else {
            Ok(())
        }
    };
    let mut parents: BTreeMap<&str, &str> = nodes
        .iter()
        .map(|(id, node)| (*id, node.parent.as_str()))
        .collect();
    let mut targets = BTreeSet::new();
    for change in changes {
        if !targets.insert(change.node.as_str()) {
            return Err(HierarchyError::DuplicateTarget(change.node.clone()));
        }
        require_visible(&change.node)?;
        if !matches!(nodes[change.node.as_str()].kind.as_str(), "list" | "item") {
            return Err(HierarchyError::UnsupportedTarget(change.node.clone()));
        }
        parents.insert(change.node.as_str(), change.parent.as_str());
    }
    // Validate the final graph, including unchanged relations. Do not project
    // illegal local intentions through the remote orphan/cycle repair policy.
    for parent in parents.values() {
        if *parent != ROOT {
            require_visible(parent)?;
            if nodes[*parent].kind != "list" {
                return Err(HierarchyError::IllegalParent((*parent).to_owned()));
            }
        }
    }
    let mut depths: BTreeMap<&str, usize> = BTreeMap::new();
    for id in nodes.keys() {
        let mut cursor = *id;
        let mut path = Vec::new();
        let mut seen = BTreeSet::new();
        while cursor != ROOT && !depths.contains_key(cursor) {
            if !seen.insert(cursor) {
                return Err(HierarchyError::Cycle(cursor.to_owned()));
            }
            path.push(cursor);
            if path.len() > MAX_TEXT_DEPTH {
                return Err(HierarchyError::DepthLimit((*id).to_owned()));
            }
            cursor = parents[cursor];
        }
        let mut depth = depths.get(cursor).copied().unwrap_or(0);
        for node in path.into_iter().rev() {
            depth += 1;
            if depth > MAX_TEXT_DEPTH {
                return Err(HierarchyError::DepthLimit((*id).to_owned()));
            }
            depths.insert(node, depth);
        }
    }
    Ok(())
}
